import * as Handsontable from '../../handsontable';

const baseVersion = Handsontable.baseVersion;
const buildDate = Handsontable.buildDate;
const packageName = Handsontable.packageName;
const version = Handsontable.version;
